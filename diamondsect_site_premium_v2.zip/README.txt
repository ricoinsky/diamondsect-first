DIAMONDSECT — site premium (estático)

Arquivos principais:
- index.html
- ternos.html / perfumaria.html / joias.html
- carrinho.html
- admin.html (cadastro de produtos)
- css/style.css
- js/common.js (header inteligente + contador)
- js/shop.js (vitrine + ordenação + carrinho)
- js/cart.js (carrinho + cupom + frete estimado)
- js/admin.js (painel de cadastro, import/export JSON)

Como usar:
1) Abra admin.html e cadastre seus produtos (nome, categoria, preço e imagem).
2) Volte para index.html / categorias e os produtos vão aparecer automaticamente.
